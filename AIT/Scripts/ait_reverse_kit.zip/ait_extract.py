import struct
import csv

# === CONFIG ===
INPUT_FILE = 'bru1_dtmx.ait'
OUTPUT_CSV = 'waypoints.csv'
OUTPUT_OBJ = 'waypoints.obj'

# === Abrir arquivo ===
with open(INPUT_FILE, 'rb') as f:
    data = f.read()

# === Função: extrair blocos de floats ===
def extract_floats(data):
    floats = []
    for i in range(0, len(data) - 4, 4):
        chunk = data[i:i+4]
        if len(chunk) < 4:
            continue
        val = struct.unpack('<f', chunk)[0]
        # Heurística: valor aceitável
        if -100000 < val < 100000:
            floats.append(val)
    return floats

# === Extrair ===
floats = extract_floats(data)

# === Salvar CSV ===
with open(OUTPUT_CSV, 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(['Index', 'Value'])
    for i, val in enumerate(floats):
        writer.writerow([i, val])

# === Gerar OBJ (se 3D) ===
# Assume sequência de (X,Y,Z) consecutiva
with open(OUTPUT_OBJ, 'w') as objfile:
    for i in range(0, len(floats) - 2, 3):
        x, y, z = floats[i], floats[i+1], floats[i+2]
        objfile.write(f'v {x} {y} {z}\n')
    for i in range(1, len(floats)//3):
        objfile.write(f'l {i} {i+1}\n')

print(f"Extraído {len(floats)} floats. CSV e OBJ gerados!")
