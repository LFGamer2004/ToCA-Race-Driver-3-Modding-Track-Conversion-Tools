
=====================================
DVR <=> CSV Converter Kit
=====================================

Inclui:
- dvr_to_csv.py : Converte .DVR binário para CSV de floats
- csv_to_dvr.py : Converte CSV editado de volta para .DVR binário

====================
USO
====================

1) DVR ➜ CSV:
- Coloque seu .DVR como 'input.dvr'
- Rode: python dvr_to_csv.py
- Edite 'output.csv' no Excel ou outro editor.

2) CSV ➜ DVR:
- Salve CSV com a mesma estrutura: Index, Value
- Rode: python csv_to_dvr.py
- Gera 'rebuild.dvr'

====================
IMPORTANTE
====================

- Este kit assume blocos 100% float32 sem cabeçalhos complexos.
- Teste sempre em cópias. Para blocos de estrutura avançada
  (keyframes com índice, blend, flags) adapte o script!
