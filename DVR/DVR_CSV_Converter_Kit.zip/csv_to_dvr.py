
import struct
import csv

INPUT_FILE = "output.csv"
OUTPUT_FILE = "rebuild.dvr"

floats = []

with open(INPUT_FILE, newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        floats.append(float(row["Value"]))

with open(OUTPUT_FILE, "wb") as f:
    for val in floats:
        f.write(struct.pack('<f', val))

print(f"Reconstruído: {OUTPUT_FILE} ({len(floats)} floats)")
