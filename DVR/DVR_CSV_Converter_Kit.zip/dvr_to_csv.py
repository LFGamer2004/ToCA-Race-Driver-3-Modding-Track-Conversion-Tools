
import struct
import csv

INPUT_FILE = "input.dvr"
OUTPUT_FILE = "output.csv"

with open(INPUT_FILE, "rb") as f:
    data = f.read()

floats = []
for i in range(0, len(data), 4):
    chunk = data[i:i+4]
    if len(chunk) == 4:
        val = struct.unpack('<f', chunk)[0]
        floats.append(val)

with open(OUTPUT_FILE, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["Index", "Value"])
    for idx, val in enumerate(floats):
        writer.writerow([idx, val])

print(f"Exportado: {OUTPUT_FILE} ({len(floats)} floats)")
