
=====================================
PX <=> OBJ Converter Kit
=====================================

Inclui:
- px_to_obj.py : Converte .PX para .OBJ
- obj_to_px.py : Converte .OBJ para .PX

====================
COMO USAR
====================

1) px_to_obj.py
- Ajuste o 'offset', 'num_vertices' e 'num_faces' com base no seu .PX real.
- Renomeie seu arquivo para 'input.px' ou edite o script.
- Rode: python px_to_obj.py

2) obj_to_px.py
- Edite sua malha no Blender, exporte como .OBJ (apenas vertices e faces!)
- Renomeie para 'input.obj' ou edite o script.
- Rode: python obj_to_px.py

====================
IMPORTANTE
====================

- Esses scripts são protótipos. Para .PX real do ToCA Race Driver 3,
  você precisa seguir offsets e blocos corretos do ModelFormat.cpp.
- Teste sempre em cópias!

Bom modding!
